export const colorTheme = {
	green: '#0a7558',
	peachWhite: '#fdf9f5',
	jet: '#302b26',
	antiqueWhite: '#fbe7d0',
	zinc: '#16191E',
	lightZinc: '#868686',
};